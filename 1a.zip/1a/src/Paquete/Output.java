import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author Jacqueline
 */
public class Output {

    public Output() {
        System.out.println("***************************");
    }

    /**
     * @param OutFile 
     * @param outText
     */

    public void writeData(String outFile, String outText) {
	
        BufferedWriter output = null;
        
        try 
    
            {
        
                File file = new File(outFile);
                output = new BufferedWriter(new FileWriter(file));
                output.write(outText);
                output.close();
            } 
    
        catch ( IOException e ) 
    
            {
                e.printStackTrace();
            }   
        }
}
