/**
 * @author Jacqueline
 */

public class Data {

    public Data() {
    }

    /**
     * @param data
     */

    public String[] saveData(String data) {
        // throw new UnsupportedOperationException();
        String[] arrData = data.split(",");
        return arrData;
    }

}
