import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author Jacqueline
 */

public class Input {

    public Input() {
    }

    
    private String data;
    private BufferedReader br;

    /**
     * @param inFile
     */

    public String readData(String inFile) {
        System.out.println("ejecutando readData ...");
		try 
			{
				br = new BufferedReader(new FileReader(inFile));
				StringBuilder sb = new StringBuilder();
				String line;
				// = br.readLine();
				while ( (line = br.readLine()) != null ) 
					{
						sb.append(line);
                        sb.append(",");
                        System.out.println("line ..." + line);
					}
				data = sb.toString();
			} 
		catch (IOException e) 
			{
                System.out.println("error : " + e);
				e.printStackTrace();
			}
	
	return data;
	}
}
